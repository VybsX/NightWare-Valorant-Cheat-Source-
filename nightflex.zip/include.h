#include <thread>
#include <cstdlib>
#include <tchar.h>
#include <urlmon.h>
#include <string>
#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <fstream>
#include <vector>
#include <filesystem>
#include <dwmapi.h>
#include <psapi.h>
#include <math.h>
// GUI includes
#include "directx/d3dx9.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx9.h"
#include "ImGui/imgui_impl_win32.h"

#pragma comment (lib, "dwmapi.lib")
#pragma comment (lib, "d3d9.lib")
#pragma comment(lib, "urlmon.lib")
